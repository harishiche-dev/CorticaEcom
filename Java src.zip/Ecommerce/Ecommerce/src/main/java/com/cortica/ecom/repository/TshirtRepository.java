package com.cortica.ecom.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cortica.ecom.entity.Tshirt;

@Repository
public interface TshirtRepository extends JpaRepository<Tshirt, Long> {
    Tshirt findByType(String type);
}
