package com.cortica.ecom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cortica.ecom.entity.Tshirt;
import com.cortica.ecom.service.TshirtService;

@RestController
@RequestMapping("/api/tshirts")
@CrossOrigin(origins = "http://localhost:4200")
public class TshirtController {

    @Autowired
    private TshirtService tshirtService;

    @GetMapping
    public List<Tshirt> getAllTshirts() {
        return tshirtService.getAllTshirts();
    }

    @PostMapping("/addToCart")
    public String addToCart(@RequestBody Tshirt tshirt) {
        boolean success = tshirtService.addToCart(tshirt.getType(), tshirt.getQuantity());
        return success ? "Added to cart" : "Out of stock";
    }
    
    @PostMapping("/restockTshirt")
    public String restockTshirt(@RequestBody Tshirt tshirt) {
        boolean success = tshirtService.restockTshirt(tshirt.getType(), tshirt.getQuantity());
        return success ? "Restocked successfully" : "T-shirt type not found";
    }
}
