package com.cortica.ecom.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cortica.ecom.dao.TshirtDAO;
import com.cortica.ecom.entity.Tshirt;
import com.cortica.ecom.repository.TshirtRepository;

@Service
public class TshirtService {

    @Autowired
    private TshirtRepository tshirtRepository;

    public List<Tshirt> getAllTshirts() {
        return tshirtRepository.findAll();
    }

    public boolean addToCart(String type, int quantity) {
        Tshirt tshirt = tshirtRepository.findByType(type);
        if (tshirt != null && tshirt.getQuantity() >= quantity) {
            tshirt.setQuantity(tshirt.getQuantity() - quantity);
            tshirtRepository.save(tshirt);
            return true;
        } else {
            return false;
        }
    }
    
    public boolean restockTshirt(String type, int quantity) {
        Tshirt tshirt = tshirtRepository.findByType(type);
        if (tshirt != null) {
            tshirt.setQuantity(tshirt.getQuantity() + quantity);
            tshirtRepository.save(tshirt);
            return true;
        } else {
            return false;
        }
    }
}
