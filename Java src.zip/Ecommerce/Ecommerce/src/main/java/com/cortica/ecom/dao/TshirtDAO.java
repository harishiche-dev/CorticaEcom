package com.cortica.ecom.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cortica.ecom.entity.Tshirt;

@Repository
public class TshirtDAO {

    @Autowired
    private SessionFactory factory;

    public List<Tshirt> getAllTshirts() {
        try (Session session = factory.openSession()) {
            Query<Tshirt> query = session.createQuery("from Tshirt", Tshirt.class);
            return query.list();
        }
    }

    public void addToCart(Tshirt tshirt) {
        try (Session session = factory.openSession()) {
            session.beginTransaction();
            session.merge(tshirt);
            session.getTransaction().commit();
        }
    }

    public void restockTshirt(Tshirt tshirt) {
        try (Session session = factory.openSession()) {
            session.beginTransaction();
            session.update(tshirt);
            session.getTransaction().commit();
        }
    }
}
