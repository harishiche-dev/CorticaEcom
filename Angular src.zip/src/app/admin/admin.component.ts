import { Component, OnInit } from '@angular/core';
import { TshirtService } from '../tshirt.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  tshirts: any[] = [];
  restockQuantity: number = 0;
  selectedType: string = '';

  constructor(private tshirtService: TshirtService) { }

  ngOnInit(): void {
    this.tshirtService.getTshirts().subscribe(data => {
      this.tshirts = data;
      console.log('Tshirts loaded:', this.tshirts); // Debugging line
    });
  }

  restock(): void {
    if (this.selectedType && this.restockQuantity > 0) {
      this.tshirtService.restockTshirt(this.selectedType, this.restockQuantity).subscribe(response => {
        alert('Restock successful');
        this.ngOnInit(); // Refresh the list
      });
    } else {
      alert('Please select a t-shirt type and enter a valid quantity');
    }
  }
}
