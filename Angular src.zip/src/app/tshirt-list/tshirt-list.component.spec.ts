import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TshirtListComponent } from './tshirt-list.component';

describe('TshirtListComponent', () => {
  let component: TshirtListComponent;
  let fixture: ComponentFixture<TshirtListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TshirtListComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TshirtListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
