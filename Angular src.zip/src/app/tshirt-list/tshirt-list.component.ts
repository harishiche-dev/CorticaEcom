import { Component, OnInit } from '@angular/core';
import { TshirtService } from '../tshirt.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tshirt-list',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './tshirt-list.component.html',
  styleUrls: ['./tshirt-list.component.css']
})
export class TshirtListComponent implements OnInit {
  tshirts: any[] = [];

  constructor(private tshirtService: TshirtService, private router:Router) { 
    
  }

  ngOnInit(): void {
    this.tshirtService.getTshirts().subscribe(data => {
      this.tshirts = data;
    });
  }

  addToCart(type: string): void {
    this.tshirtService.addToCart(type, 1).subscribe(response => {
      alert(response);
      this.ngOnInit(); // Refresh the list
    });
  }
}
