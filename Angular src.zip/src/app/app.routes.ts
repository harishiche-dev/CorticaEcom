import { Routes } from '@angular/router';
import { TshirtListComponent } from './tshirt-list/tshirt-list.component';
import { AdminComponent } from './admin/admin.component';

export const routes: Routes = [
  { path: '', component: TshirtListComponent }, // The default route should match '' for the home component
  { path: 'admin', component: AdminComponent },
   { path: '**', redirectTo: '/tshirt-list' } 
];
